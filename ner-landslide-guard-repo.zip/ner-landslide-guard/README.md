# NER Landslide Guard

AI-based landslide early warning and risk monitoring demo for North Eastern India.
Single-file static site (HTML, CSS, JS, Chart.js). All data is simulated.

Live site (after deploy): https://<your-username>.github.io/ner-landslide-guard/

## Deploy on GitHub Pages
1. Create an empty repo named `ner-landslide-guard` on GitHub.
2. Run:
   git init && git add . && git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/ner-landslide-guard.git
   git push -u origin main
3. Repo Settings > Pages > Source: Deploy from branch > main / (root) > Save.
